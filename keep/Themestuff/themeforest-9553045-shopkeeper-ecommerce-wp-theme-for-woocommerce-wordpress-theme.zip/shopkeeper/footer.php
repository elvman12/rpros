					<?php global $page_id, $woocommerce, $shopkeeper_theme_options; ?>
                    
                    <?php

                    $page_footer_option = "on";
					
					if (get_post_meta( $page_id, 'footer_meta_box_check', true )) {
						$page_footer_option = get_post_meta( $page_id, 'footer_meta_box_check', true );
					}

					if (class_exists('WooCommerce')) {
						if (is_shop() && get_post_meta( get_option( 'woocommerce_shop_page_id' ), 'footer_meta_box_check', true )) {
							$page_footer_option = get_post_meta( get_option( 'woocommerce_shop_page_id' ), 'footer_meta_box_check', true );
						}
					}
					
					?>
					
					<?php if ( $page_footer_option == "on" ) : ?>
                    
                    <footer id="site-footer" role="contentinfo">
                        
                    	 <?php if ( is_active_sidebar( 'footer-widget-area' ) ) : ?>
						 
							<div class="trigger-footer-widget-area">
								<span class="trigger-footer-widget-icon"></span>
							</div>
						
							<div class="site-footer-widget-area">
								<div class="row">
									<?php dynamic_sidebar( 'footer-widget-area' ); ?>
								</div><!-- .row -->
							</div><!-- .site-footer-widget-area -->
                        
						<?php endif; ?>
                        
                        <div class="site-footer-copyright-area">
                            <div class="row">
								<div class="large-12 columns">
				
									<?php if ( (isset($shopkeeper_theme_options['footer_social_icons'])) && (trim($shopkeeper_theme_options['footer_social_icons']) == "1" ) ) : ?>
                                    
                                    <ul class="footer_socials_wrapper">
                                        
                                        <?php
                        
										$facebook = "";
										$pinterest = "";
										$linkedin = "";
										$twitter = "";
										$googleplus = "";
										$rss = "";
										$tumblr = "";
										$instagram = "";
										$youtube = "";
										$vimeo = "";
										$behance = "";
										$dribble = "";
										$flickr = "";
										$git = "";
										$skype = "";
										$weibo = "";
										$foursquare = "";
										$soundcloud = "";
										$vk = "";
										$tripadvisor = "";
										$wechat = "";
										
										if ( isset ($shopkeeper_theme_options['facebook_link']) ) $facebook = $shopkeeper_theme_options['facebook_link'];
										if ( isset ($shopkeeper_theme_options['pinterest_link']) ) $pinterest = $shopkeeper_theme_options['pinterest_link'];
										if ( isset ($shopkeeper_theme_options['linkedin_link']) ) $linkedin = $shopkeeper_theme_options['linkedin_link'];
										if ( isset ($shopkeeper_theme_options['twitter_link']) ) $twitter = $shopkeeper_theme_options['twitter_link'];
										if ( isset ($shopkeeper_theme_options['googleplus_link']) ) $googleplus = $shopkeeper_theme_options['googleplus_link'];
										if ( isset ($shopkeeper_theme_options['rss_link']) ) $rss = $shopkeeper_theme_options['rss_link'];
										if ( isset ($shopkeeper_theme_options['tumblr_link']) ) $tumblr = $shopkeeper_theme_options['tumblr_link'];
										if ( isset ($shopkeeper_theme_options['instagram_link']) ) $instagram = $shopkeeper_theme_options['instagram_link'];
										if ( isset ($shopkeeper_theme_options['youtube_link']) ) $youtube = $shopkeeper_theme_options['youtube_link'];
										if ( isset ($shopkeeper_theme_options['vimeo_link']) ) $vimeo = $shopkeeper_theme_options['vimeo_link'];
										if ( isset ($shopkeeper_theme_options['behance_link']) ) $behance = $shopkeeper_theme_options['behance_link'];
										if ( isset ($shopkeeper_theme_options['dribble_link']) ) $dribble = $shopkeeper_theme_options['dribble_link'];
										if ( isset ($shopkeeper_theme_options['flickr_link']) ) $flickr = $shopkeeper_theme_options['flickr_link'];
										if ( isset ($shopkeeper_theme_options['git_link']) ) $git = $shopkeeper_theme_options['git_link'];
										if ( isset ($shopkeeper_theme_options['skype_link']) ) $skype = $shopkeeper_theme_options['skype_link'];
										if ( isset ($shopkeeper_theme_options['weibo_link']) ) $weibo = $shopkeeper_theme_options['weibo_link'];
										if ( isset ($shopkeeper_theme_options['foursquare_link']) ) $foursquare = $shopkeeper_theme_options['foursquare_link'];
										if ( isset ($shopkeeper_theme_options['soundcloud_link']) ) $soundcloud = $shopkeeper_theme_options['soundcloud_link'];
										if ( isset ($shopkeeper_theme_options['vk_link']) ) $vk = $shopkeeper_theme_options['vk_link'];
										if ( isset ($shopkeeper_theme_options['houzz_link']) ) $houzz = $shopkeeper_theme_options['houzz_link'];
										if ( isset ($shopkeeper_theme_options['naver_line_link']) ) $naver = $shopkeeper_theme_options['naver_line_link'];
										if ( isset ($shopkeeper_theme_options['tripadvisor_link']) ) $tripadvisor = $shopkeeper_theme_options['tripadvisor_link'];
										if ( isset ($shopkeeper_theme_options['wechat_link']) ) $wechat = $shopkeeper_theme_options['wechat_link'];
										
										if ( $facebook != "" ) echo('<li><a href="' . $facebook . '" target="_blank" class="social_media"><i class="fa fa-facebook"></i></a></li>' );
										if ( $pinterest != "" ) echo('<li><a href="' . $pinterest . '" target="_blank" class="social_media"><i class="fa fa-pinterest"></i></a></li>' );
										if ( $linkedin != "" ) echo('<li><a href="' . $linkedin . '" target="_blank" class="social_media"><i class="fa fa-linkedin"></i></a></li>' );
										if ( $twitter != "" ) echo('<li><a href="' . $twitter . '" target="_blank" class="social_media"><i class="fa fa-twitter"></i></a></li>' );
										if ( $googleplus != "" ) echo('<li><a href="' . $googleplus . '" target="_blank" class="social_media"><i class="fa fa-google-plus"></i></a></li>');
										if ( $rss != "" ) echo('<li><a href="' . $rss . '" target="_blank" class="social_media"><i class="fa fa-rss"></i></a></li>' );
										if ( $tumblr != "" ) echo('<li><a href="' . $tumblr . '" target="_blank" class="social_media"><i class="fa fa-tumblr"></i></a></li>' );
										if ( $instagram != "" ) echo('<li><a href="' . $instagram . '" target="_blank" class="social_media"><i class="fa fa-instagram"></i></a></li>' );
										if ( $youtube != "" ) echo('<li><a href="' . $youtube . '" target="_blank" class="social_media"><i class="fa fa-youtube"></i></a></li>' );
										if ( $vimeo != "" ) echo('<li><a href="' . $vimeo . '" target="_blank" class="social_media"><i class="fa fa-vimeo-square"></i></a></li>' );
										if ( $behance != "" ) echo('<li><a href="' . $behance . '" target="_blank" class="social_media"><i class="fa fa-behance"></i></a></li>' );
										if ( $dribble != "" ) echo('<li><a href="' . $dribble . '" target="_blank" class="social_media"><i class="fa fa-dribbble"></i></a></li>' );
										if ( $flickr != "" ) echo('<li><a href="' . $flickr . '" target="_blank" class="social_media"><i class="fa fa-flickr"></i></a></li>' );
										if ( $git != "" ) echo('<li><a href="' . $git . '" target="_blank" class="social_media"><i class="fa fa-git"></i></a></li>' );
										if ( $skype != "" ) echo('<li><a href="' . $skype . '" target="_blank" class="social_media"><i class="fa fa-skype"></i></a></li>' );
										if ( $weibo != "" ) echo('<li><a href="' . $weibo . '" target="_blank" class="social_media"><i class="fa fa-weibo"></i></a></li>' );
										if ( $foursquare != "" ) echo('<li><a href="' . $foursquare . '" target="_blank" class="social_media"><i class="fa fa-foursquare"></i></a></li>' );
										if ( $soundcloud != "" ) echo('<li><a href="' . $soundcloud . '" target="_blank" class="social_media"><i class="fa fa-soundcloud"></i></a></li>' );
										if ( $vk != "" ) echo('<li><a href="' . $vk . '" target="_blank" class="social_media"><i class="fa fa-vk"></i></a></li>' );
										if ( $houzz != "" ) echo('<li><a href="' . $houzz . '" target="_blank" class="social_media"><i class="fa fa-houzz"></i></a></li>' );
										if ( $naver != "" ) echo('<li><a href="' . $naver . '" target="_blank" class="social_media"><i class="spk-icon spk-icon-naver-line-logo"></i></a></li>' );
										if ( $tripadvisor != "" ) echo('<li><a href="' . $tripadvisor . '" target="_blank" class="social_media"><i class="fa fa-tripadvisor"></i></a></li>' );
										if ( $wechat != "" ) echo('<li><a href="' . $wechat . '" target="_blank" class="social_media"><i class="fa fa-weixin"></i></a></li>' );
										
										?>
                                        
									</ul>
                                    
                                    <?php endif; ?>
                                
									<nav class="footer-navigation-wrapper" role="navigation">                    
										<?php 
											wp_nav_menu(array(
												'theme_location'  => 'footer-navigation',
												'fallback_cb'     => false,
												'container'       => false,
												'depth' 		  => 1,
												'items_wrap'      => '<ul class="%1$s">%3$s</ul>',
											));
										?>           
									</nav><!-- #site-navigation -->   
								
                                    <div class="copyright_text">
                                        <?php if ( (isset($shopkeeper_theme_options['footer_copyright_text'])) && (trim($shopkeeper_theme_options['footer_copyright_text']) != "" ) ) { ?>
                                            <?php _e( $shopkeeper_theme_options['footer_copyright_text'], 'shopkeeper' ); ?>
                                        <?php } ?>
                                    </div><!-- .copyright_text -->  
                            
								</div><!--.large-12-->
							</div><!-- .row --> 
                        </div><!-- .site-footer-copyright-area -->
                               
                    </footer>
                    
                    <?php endif; ?>
                    
                </div><!-- #page_wrapper -->
                        
            </div><!-- /st-content -->
        </div><!-- /st-pusher -->        
        
        <?php if (class_exists('WooCommerce') && (is_shop() || is_product_category() || is_product_tag() )) : ?>
        <nav class="st-menu <?php echo is_rtl() ? 'slide-from-right' : 'slide-from-left' ?> <?php echo ( is_active_sidebar( 'catalog-widget-area' ) && ( isset($shopkeeper_theme_options['sidebar_style']) && ( $shopkeeper_theme_options['sidebar_style'] == "0" ) ) ) ? 'hide-for-large-up':''; ?> <?php echo ( is_active_sidebar( 'catalog-widget-area' ) ) ? 'shop-has-sidebar':''; ?>">
            <div class="nano">
                <div class="content">
					
                    <div class="offcanvas_content_left wpb_widgetised_column">
                    
                        <div id="filters-offcanvas">
                            <?php if ( is_active_sidebar( 'catalog-widget-area' ) ) : ?>
                                <?php dynamic_sidebar( 'catalog-widget-area' ); ?>
                            <?php endif; ?>
                        </div>
                    
                    </div>
                    
                </div>
            </div>
        </nav>
    	<?php endif; ?>
        

        <nav class="st-menu <?php echo is_rtl() ? 'slide-from-left' : 'slide-from-right' ?>">
            <div class="nano">
                <div class="content">
                
                    <div class="offcanvas_content_right">                	
                        
                        <div id="mobiles-menu-offcanvas">
                                
                                <?php if ( (isset($shopkeeper_theme_options['main_header_search_bar'])) && ($shopkeeper_theme_options['main_header_search_bar'] == "1") ) : ?>

                                <div class="mobile-search hide-for-large-up">
									
										<?php
										if (class_exists('WooCommerce')) {
											the_widget( 'WC_Widget_Product_Search', 'title=' );
										} else {
											the_widget( 'WP_Widget_Search', 'title=' );
										}
										?>
										
										<div class="mobile_search_submit">
											<i class="fspk-icon-search"></i>
										</div>
								
                                </div>

                                <?php endif; ?>
                                
	                            <?php if ( (isset($shopkeeper_theme_options['main_header_layout'])) && ( $shopkeeper_theme_options['main_header_layout'] != "2" ) && ( $shopkeeper_theme_options['main_header_layout'] != "22" ) ) : ?>

	                                <nav class="mobile-navigation primary-navigation hide-for-large-up" role="navigation">
	                                <?php 
	                                    wp_nav_menu(array(
	                                        'theme_location'  => 'main-navigation',
	                                        'fallback_cb'     => false,
	                                        'container'       => false,
	                                        'items_wrap'      => '<ul id="%1$s">%3$s</ul>',
	                                    ));
	                                ?>
	                                </nav>
	                                
	                            <?php endif; ?>
	                            
	                            <?php if ( (isset($shopkeeper_theme_options['main_header_layout'])) && ( $shopkeeper_theme_options['main_header_layout'] == "2" || $shopkeeper_theme_options['main_header_layout'] == "22" ) ) : ?>
	                                
	                                <nav class="mobile-navigation hide-for-large-up" role="navigation">
	                                <?php 
	                                    wp_nav_menu(array(
	                                        'theme_location'  => 'centered_header_left_navigation',
	                                        'fallback_cb'     => false,
	                                        'container'       => false,
	                                        'items_wrap'      => '<ul id="%1$s">%3$s</ul>',
	                                    ));
	                                ?>
	                                </nav>
	                                
	                                <nav class="mobile-navigation hide-for-large-up" role="navigation">
	                                <?php 
	                                    wp_nav_menu(array(
	                                        'theme_location'  => 'centered_header_right_navigation',
	                                        'fallback_cb'     => false,
	                                        'container'       => false,
	                                        'items_wrap'      => '<ul id="%1$s">%3$s</ul>',
	                                    ));
	                                ?>
	                                </nav>
	                                
	                            <?php endif; ?>
								
								<?php if ( (isset($shopkeeper_theme_options['main_header_off_canvas'])) && (trim($shopkeeper_theme_options['main_header_off_canvas']) == "1" ) ) : ?>
	                                <nav class="mobile-navigation" role="navigation">
	                                <?php 
	                                    wp_nav_menu(array(
	                                        'theme_location'  => 'secondary_navigation',
	                                        'fallback_cb'     => false,
	                                        'container'       => false,
	                                        'items_wrap'      => '<ul id="%1$s">%3$s</ul>',
	                                    ));
	                                ?>
	                                </nav>
	                            <?php endif; ?>
	                            
	                            <?php						
								$theme_locations  = get_nav_menu_locations();
								if (isset($theme_locations['top-bar-navigation'])) {
									$menu_obj = get_term($theme_locations['top-bar-navigation'], 'nav_menu');
								}
								
								if ( (isset($menu_obj->count) && ($menu_obj->count > 0)) || (is_user_logged_in()) ) {
								?>
								
									<?php if ( (isset($shopkeeper_theme_options['top_bar_switch'])) && ($shopkeeper_theme_options['top_bar_switch'] == "1" ) ) : ?>
	                                    <nav class="mobile-navigation hide-for-large-up" role="navigation">								
	                                    <?php 
	                                        wp_nav_menu(array(
	                                            'theme_location'  => 'top-bar-navigation',
	                                            'fallback_cb'     => false,
	                                            'container'       => false,
	                                            'items_wrap'      => '<ul id="%1$s">%3$s</ul>',
	                                        ));
	                                    ?>
	                                    
	                                    <?php if ( is_user_logged_in() ) { ?>
	                                        <ul><li><a href="<?php echo get_site_url(); ?>/?<?php echo get_option('woocommerce_logout_endpoint'); ?>=true" class="logout_link"><?php _e('Logout', 'woocommerce'); ?></a></li></ul>
	                                    <?php } ?>
	                                    </nav>
	                                <?php endif; ?>
								
								<?php } ?>
								
								<div class="language-and-currency-offcanvas hide-for-large-up">
								
									<?php if (function_exists('icl_get_languages')) { ?>
					                    <?php languages_top_bar(); ?>
									<?php } ?>
									
									<?php if (class_exists('woocommerce_wpml')) { ?>
										<?php echo(do_shortcode('[currency_switcher format="%code% - (%symbol%)"]')); ?>
									<?php } ?>
				
	                            
	                            </div>
                            
                        </div>

                        <?php if ( is_active_sidebar( 'offcanvas-widget-area' ) ) : ?>
                        	<div class="shop_sidebar wpb_widgetised_column">
                            	<?php dynamic_sidebar( 'offcanvas-widget-area' ); ?>
                            </div>
                        <?php endif; ?>
                                            
                    </div>
                
                </div>
            </div>
        </nav>
	
    </div><!-- /st-container -->

    <!-- ******************************************************************** -->
    <!-- * Mini Cart ******************************************************** -->
    <!-- ******************************************************************** -->

    <?php if ( (isset($shopkeeper_theme_options['main_header_shopping_bag'])) && ($shopkeeper_theme_options['main_header_shopping_bag'] == "1") ) : ?>
	    <div class="shopkeeper-mini-cart">
	    	<?php if ( class_exists( 'WC_Widget_Cart' ) ) { the_widget( 'WC_Widget_Cart' ); } ?>

	    	<?php 
	    		if (!empty($shopkeeper_theme_options['main_header_minicart_message'])):
	    			echo '<div class="minicart-message">'. esc_html__( $shopkeeper_theme_options['main_header_minicart_message'], 'getbowtied' ) .'</div>';
	    		endif;
	    	?>
	    </div>
	<?php endif; ?>

	<!-- ******************************************************************** -->
    <!-- * Site Search ****************************************************** -->
    <!-- ******************************************************************** -->
	<div class="site-search">
		<div class="site-search-inner">
		<?php
		if (class_exists('WooCommerce')) {
			the_widget( 'WC_Widget_Product_Search', 'title=' );
		} else {
			the_widget( 'WP_Widget_Search', 'title=' );
		}
		?>
		</div>
	</div><!-- .site-search -->

	<!-- ******************************************************************** -->
    <!-- * Back To Top Button *********************************************** -->
    <!-- ******************************************************************** -->
    <?php $shopkeeper_theme_options['back_to_top_button'] = isset($shopkeeper_theme_options['back_to_top_button']) ? $shopkeeper_theme_options['back_to_top_button'] : '1'; ?>
	<?php if ( $shopkeeper_theme_options['back_to_top_button'] == '1') : ?>
	<a href="#0" class="cd-top">
		<i class="spk-icon spk-icon-up-small" aria-hidden="true"></i>

	</a>
	<?php endif; ?>


	<!-- ******************************************************************** -->
    <!-- * Product Quick View *********************************************** -->
    <!-- ******************************************************************** -->
    <!-- <div id="quick_view_container">
		<div id="placeholder_product_quick_view" class="woocommerce"></div>
	</div> -->

	<div class="cd-quick-view woocommerce">
	</div> <!-- cd-quick-view -->

    <!-- ******************************************************************** -->
    <!-- * Custom Footer JavaScript Code ************************************ -->
    <!-- ******************************************************************** -->
    
    <?php if ( (isset($shopkeeper_theme_options['footer_js'])) && ($shopkeeper_theme_options['footer_js'] != "") ) : ?>
		<?php echo $shopkeeper_theme_options['footer_js']; ?>
    <?php endif; ?>
	
    <!-- ******************************************************************** -->
    <!-- * WP Footer() ****************************************************** -->
    <!-- ******************************************************************** -->
	
	<?php wp_footer(); ?>
    
</body>

</html>